#Neha Tirunagiri        26/11/2022
# Assignment #6 Naval Battle


import gameBoard
import gamePlay

def main():

    gameOver = False

    gameboardChoice = 0
    humanGameBoard = None
    targetBoard = None
    computerGameBoard = None
    
    numHumanTargets = 0
    numComputerTargets = 0
    
    print("Welcome to Naval Battle!")
    print()

    print("By:Neha Tirunagiri ")
    print("[COM S 127 A]")
    print()

    while gameOver == False:
        choice = input("[p]lay, [i]nstructions, or [q]uit?: ")
        print()
        if choice == "p": 

            gameboardChoice=gameBoard.chooseHumanGameBoard()
            pass
            print("Computer Game Board! \n")
            humanGameBoard, numHumanTargets=gameBoard.loadGameBoard(gameboardChoice)
            pass

            gameboardChoice=gameBoard.chooseComputerGameBoard()
            pass

            computerGameBoard, numComputerTargets=gameBoard.loadGameBoard(gameboardChoice)
            pass

            targetBoard = gameBoard.loadTargetBoard()
            pass

            gamePlay.runGame(humanGameBoard, targetBoard, computerGameBoard, numHumanTargets, numComputerTargets)

        elif choice == "i":
            print("Enter a row and a column to fire on the COMPUTER's ships!")
            print("Sink all the COMPUTER's vessels before they sink yours!")
            pass
        elif choice == "q":
            gameOver=True
            print("Goodbye!")
            pass
        else:
            print()
            print("Please enter [p], [i], or [q]...")
            print()

if __name__ == "__main__":
    main()