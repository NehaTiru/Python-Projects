# Neha Tirunagiri            26-11-2022
# Assignment #6 Naval Battle

import gameBoard
import gameInput

w=10
h=10

def _humanTurn(humanGameBoard, targetBoard, computerGameBoard, numComputerTargets):


    print ("Human Turn")
    print("")
    gameBoard.printBoard(targetBoard, w, h)
    print("")
    gameBoard.printBoard(humanGameBoard, w, h)
    pass

    while True:
        row,col=gameInput.getHumanInput()
        pass

        print(f"The human targets coordinates ({row},{col})")

        pass

        if computerGameBoard[row][col]=="*":
            targetBoard[row][col]="X"
            computerGameBoard[row][col]="X"
            print ("HIT")
            numComputerTargets-=1
            break
        elif computerGameBoard[row][col]=="X":
            print("You have already attacked that spot. Pick a different spot.")

        elif computerGameBoard[row][col]=="O":
            print("You have already attacked that spot. Pick a different spot.") 
        else:
            computerGameBoard[row][col]="O"
            targetBoard[row][col]="O"
            print("MISS")
            break

    pass
    
    return humanGameBoard, targetBoard, computerGameBoard, numComputerTargets

def _computerTurn(humanGameBoard, numHumanTargets):

    
    print("Computer Turn")
    pass

    
    while True:
        row,col=gameInput.getComputerInput()
        if humanGameBoard[row][col]!="X" or "O":
            break
        
    pass

    
    print(f"The Computer targets coordinates {row},{col}")

    pass


    if humanGameBoard[row][col]=="*":
        humanGameBoard[row][col]="X"
        print("HIT")
        numHumanTargets-=1
    else:
        humanGameBoard[row][col]="O"
        print("MISS")
    pass
    
    return humanGameBoard, numHumanTargets

def _printWinner(numComputerTargets, computerGameBoard):

    if numComputerTargets==0:
        print("Human has won!")
    else:
        print("computer has won")
    pass
    
    
 
    gameBoard.printBoard(computerGameBoard,w,h)

    pass

    return

def runGame(humanGameBoard, targetBoard, computerGameBoard, numHumanTargets, numComputerTargets):

    currentTurn = 0 
    
    while numHumanTargets > 0 and numComputerTargets > 0:
        if currentTurn == 0:
            humanGameBoard, targetBoard, computerGameBoard, numComputerTargets = _humanTurn(humanGameBoard, targetBoard, computerGameBoard, numComputerTargets)
        else:
            humanGameBoard, numHumanTargets = _computerTurn(humanGameBoard, numHumanTargets)

        
        currentTurn += 1
        currentTurn %= 2
    
    
    _printWinner(numComputerTargets, computerGameBoard)

    return