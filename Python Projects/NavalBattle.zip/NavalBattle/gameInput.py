# Neha Tirunagiri             26-11-2022
# Assignment #6 Naval Battle

import random
import gameBoard

def getHumanInput():

    while True:
        row=int(input("enter the row to attack: "))
        if row <0 or row >gameBoard.GAME_BOARD_HEIGHT-1:
            print ("invalid input, try again.")
        else:
            break
    pass
    while True:
        col=int(input("enter the column to attack: "))
        if col <0 or col >gameBoard.GAME_BOARD_WIDTH-1:
            print ("invalid input, try again.")
        else:
            break
    pass
    
    return row, col

def getComputerInput():

    row=random.randint(0,gameBoard.GAME_BOARD_HEIGHT-1)
    pass

    col=random.randint(0,gameBoard.GAME_BOARD_WIDTH-1)
    pass

    return row, col