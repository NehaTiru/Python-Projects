hidden_word:str = None

displayed_word:list[str] = None


guessed_letters:list[str] = None

guesses_left:int = None


def start(word, guesses):
	global hidden_word, displayed_word, guessed_letters, guesses_left
	hidden_word = word
	guesses_left = guesses
	displayed_word = ["-"] * len(hidden_word)
	guessed_letters = []

def guess_letter(letter):
	global guesses_left, displayed_word, guessed_letters
	
	if hidden_word.find(letter) != -1:
		
		for i in range(len(hidden_word)): 
			if hidden_word[i] == letter:
				displayed_word[i] = letter
		
		guessed_letters.append(letter)
		return True
	else:
		
		guessed_letters.append(letter)
		
		guesses_left -= 1
		return False

def get_displayed_word():
	
	return displayed_word

def get_hidden_word():
	
	return hidden_word

def get_guesses_left():
	
	return guesses_left

def get_guessed_letters():
	
	return guessed_letters

def is_over():
	
	return guesses_left == 0

def is_won():
	
	return "".join(get_displayed_word()) == get_hidden_word()