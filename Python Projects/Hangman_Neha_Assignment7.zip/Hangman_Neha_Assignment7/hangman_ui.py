#Assignment7 -Hangman          #4.12.2022
#Neha Tirunagiri    
'''
This is a hangman game.
Guess the word to win and exit
Let's see if you can do it within the given time

Its pretty simple to play and understand.
All you have to do is choose in what category u need to play in and guess the specific words
Enjoy playing my name Thanks
- Neha Tirunagiri
'''
import hangman
import words

def select_game_and_word():

    print("Which version of the game would you like to play?")
    print("a. Kitchen Utensils")
    print("b. Special Words")
    print("c. Word from file")
    choice = input("Enter a, b, or c: ")

    match choice:
        case 'a':
            return words.get_kitchen_word()
        case 'b':
            return words.get_special_word()
        case 'c':
            return words.get_word_from_file('word_list.txt')
        case _:
            print("Invalid choice")
            return select_game_and_word()



def display_game():
    '''
    Prints out the current state of the game, including a stick
    figure drawn under a scaffold.
    '''
    stick_figure = ['/','\\','|','\\','/','o']
    positions = [34,35,26,27,25,18]
    health = max(0, 6 - hangman.get_guesses_left())
    scaffold = list(\
        "  ____ \n"+\
        "  1   |\n"+\
        "      |\n"+\
        "      |\n"+\
        "      |\n"+\
        "=======\n")

    for x in range(health):
        scaffold[positions[x]] = stick_figure[x]
    print("".join(scaffold))      
    print("Word so far:    " + " ".join(hangman.get_displayed_word()))
    print("Letters already guessed: " + ", ".join(hangman.get_guessed_letters()))
    print("You have " + str(hangman.get_guesses_left()) + " guesses left")


def play_game():
    '''
    Plays one round of the hangman game.
    '''
    print("Welcome to ComS 127 Hangman")
    
    hidden = select_game_and_word()
    hangman.start(hidden, 6)
    while (not hangman.is_over()):
        display_game()
        letter = input("Enter your guess: ")
        correct = hangman.guess_letter(letter)
        if correct:
            print("Good guess!")
        else:
            print("Nope.")
        if hangman.is_won():
            return print("You win!")
        elif hangman.is_over():
            display_game()
            print("Sorry, you've lost.")
    
    print("The word was " + hangman.get_hidden_word())

play_game()